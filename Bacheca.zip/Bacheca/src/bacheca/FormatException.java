package  bacheca;
/**
 * @author      Andrea Ierardi 20018785@studenti.uniupo.it, Edoardo Favorido 20018971@studenti.uniupo.it
 * @version     1.0
 */
public class FormatException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public FormatException (String msg)
	{
		super(msg);
	}
}
